﻿using System;

namespace _2
{
    class Program
    {
        static void Main(string[] args)
        {
            int n1, n2, impares=0;
            Console.WriteLine("\nNÚMEROS IMPARES EM ORDEM DECRESCENTE:\n");

            Console.WriteLine("Digite o maior número: ");//Começa contagem
            n1 = int.Parse(Console.ReadLine());

            Console.WriteLine("Digite o menor número: ");//Termina contagem
            n2 = int.Parse(Console.ReadLine());

            for (int x = n1; x >= n2; x=x-1)
            {
                
                if (x % 2 != 0) { Console.WriteLine("\n{0}", x); }
            }
        
            Console.ReadKey();

        }
    }
}
