﻿using System;

namespace _3
{
    class Program
    {
        static void Main(string[] args)
        {
            Double n, r;
            Console.WriteLine("\n Programa de tabuada:\n");
            Console.WriteLine("\nEscolha um número de 0 a 10\n");
            Console.WriteLine("Digite o número: ");
            r = Double.Parse(Console.ReadLine());

            for (int x = 0; x <= 10; x++)
            {
                n = r * x;
                Console.Write("{0}x{1}={2}\n", r, x, n);
            }
            Console.ReadKey();

        }
    }
}
