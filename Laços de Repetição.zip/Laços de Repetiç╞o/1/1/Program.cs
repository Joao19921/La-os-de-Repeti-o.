﻿using System;

namespace _1
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int x = 11; x <= 250; x++)
            {
                if (x % 2 == 0)
                {
                    Console.WriteLine(x);
                }
            }

            Console.ReadKey();

        }
    }
}
