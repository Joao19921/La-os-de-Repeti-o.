﻿using System;

namespace _9
{
    class Program
    {
        static void Main(string[] args)
        {
            //Exercício 9: Escreva um programa que leia vários números inteiros e ao final informe
            //quantos números pares, quantos números ímpares,
            //quantos números positivos e quantos números negativos foram digitados pelo usuário.
            //O programa só deve parar de rodar quando o usuário responder "S"
            //na seguinte pergunta, "Deseja encerrar o programa?". 

            Console.WriteLine("\nSeparação de números\n");
          
            int numero = 1, pares = 0, impares = 0, positivos = 0, negativos = 0, i = 1;


            do
            {
                Console.Write("Digite o " + i++ + " º número ");
                numero = int.Parse(Console.ReadLine());

                if (numero % 2 == 0)
                {
                    pares++;
                }
                else
                {
                    impares++;
                }

                if (numero >= 0)
                {
                    positivos++;
                }
                else
                {
                    negativos++;
                }
                Console.WriteLine("Após digitar seus números, tecle 0 para encerrar");
            } while (numero != 0);

            Console.WriteLine(" São" + pares + " pares , " + impares + " impares , " + positivos + " positivos e " + negativos + " negativos ");

            Console.ReadKey();

        }
    }
}
