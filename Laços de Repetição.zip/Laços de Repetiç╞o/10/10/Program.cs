﻿using System;

namespace _10
{
    class Program
    {
        static void Main(string[] args)
        {
            Double C=0, N , E, salario, salario_excedente;

            Console.WriteLine("Digite a quantidade de horas trabalhadas: ");
            N = Double.Parse(Console.ReadLine());

            do
            {
                
                if (N > 50)
                {

                    E = N - 50;
                    salario_excedente = E * 20;
                    salario = 50 * 10;
                    Console.WriteLine("Seu salário em mês será: R$ {0} e eu salário extra será: R$ {1}", salario, salario_excedente);

                }
                else
                {

                    E = 0;
                    salario = N * 10;
                    salario_excedente = E;
                    Console.WriteLine("Seu salário em mês será: R$ {0} e eu salário extra será: R$ {1}", salario, salario_excedente);


                }

            } while (C < 2);

            Console.ReadKey();


        }
    }
}
